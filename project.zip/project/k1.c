#include <stdio.h>
int main(){
int arr1 [20];
int i ;
int n ;
int j = 1;
    printf("enter nuber of aerea :");
    scanf("%d",&n);
for ( i= (n-1); i >= 0; i--)
{   printf("enter the %d number : ", j);
    scanf("%d", &arr1[i]);
    j++;
}
for(int m =0;m<n;m++){
    printf("%d\t",arr1[m]);
}

return 0; 
}