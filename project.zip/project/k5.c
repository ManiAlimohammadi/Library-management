#include<stdio.h>
int main(){
FILE *mani;
int n,i;
float a;
float m =0;
float arr1[5];
for(i=0;i<5;i++){
    mani=fopen("m.txt","r");
    fscanf(mani,"%f\t",&arr1[i]);
    fclose(mani);
}
for (int j = 0; j <5 ; j++)
{
m+=arr1[j];
}
a=m/5;
printf("the sum is : %f and avrag is : %f ",m,a);








    return 0;
}