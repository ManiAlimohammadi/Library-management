#include<stdio.h>
void arrange_three_numbers (int x,int y,int z){
int m ;
if (x>=y){
    if(x>=z){
        if(y>=z){
            printf("Sorted order of numbers:%d>%d>%d",x,y,z);
        }
        else{printf("Sorted order of numbers:%d>%d>%d",x,z,x);}
    }
    else{printf("Sorted order of numbers:%d>%d>%d",z,x,y);}
}
else{
    if(y>=z){
        if(x>=z){printf("Sorted order of numbers:%d>%d>%d",y,x,z);}
        else{printf("Sorted order of numbers:%d>%d>%d",y,z,x);}
    }
    else{printf("Sorted order of numbers:%d>%d>%d",z,y,x);}
}
}
int main()
{
    int x,y,z;
printf("Enter the three numbers you want to sort : ");
scanf("%d%d%d",&x,&y,&z);
arrange_three_numbers(x,y,z);
    return 0;
}
