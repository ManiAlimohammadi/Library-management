#include<stdio.h>
int main (){
FILE *mani;
int i,j,n;
float m;
printf("how meny numbers do you whant to enter ? ");
scanf("%d",&n);
float arr1 [n];
    for(i=0;i<n;i++){
        printf("enter the %d number : ", (i+1));
        scanf("%f", &m);
        arr1[i]=m;
    }
    for(j=0;j<n;j++){
        mani = fopen("m.txt","a");
        fprintf(mani, "%f\t",arr1[j]);
    fclose(mani);}
fclose(mani);
    return 0;
}