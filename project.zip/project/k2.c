#include <stdio.h>
void reading_the_array (int arr1 [],int n){
    int i ;
    int j = 1;
for ( i= (n-1); i >= 0; i--)
{   printf("enter the %d number : ", j);
    scanf("%d", &arr1[i]);
    j++;
}
}
int main(){
int n,m;
int arr1[20];
    printf("enter nuber of aerea :");
    scanf("%d",&n);
    reading_the_array(arr1,n); 
for( m =0;m<n;m++){
    printf("%d\t",arr1[m]);
}

return 0; 
}