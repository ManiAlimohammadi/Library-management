#include <stdio.h>

int is_prime (int n) {
    if (n <= 1) {
        return 0;
    }
    if (n <= 3) {
        return 1;
    }
    if (n % 2 == 0 || n % 3 == 0) {
        return 0;
    }
    int i = 5;
    while (i * i <= n) {
        if (n % i == 0 || n % (i + 2) == 0) {
            return 0;
        }
        i += 6;
    }
    return 1;
}

void find_primes_in_range(int start, int end) {
    printf("Prime numbers in the range [%d, %d]:\n", start, end);
    int arr1 [10000];
    int i =0;
    int sum;
    for (int num = start; num <= end; num++) {
        if (is_prime(num)) {
            printf("%d ", num);
        printf("\n");
        arr1[i]=num;
        i++;
        }
    while (sum<=1000)
    {
    for (int i = 0; i < 1000; i++)
    {
    sum+=arr1[i];
    }
    printf("sum is : %d",sum);
    }
    }
    printf("\n");
}

int main() {
    int start, end ;
    printf("Enter start of range: ");
    scanf("%d", &start);
    printf("Enter end of range: ");
    scanf("%d", &end);
    find_primes_in_range(start, end);

    return 0;

}