#include<stdio.h>
int main (){
int i ;
int b;
char ob ;
int x;
char m;
l1:
  printf("add ro vard kon");
  scanf("%d", &i);
  do
  {
    scanf("%c", &ob);
  } while (ob == ' ' || ob == '\n' || ob == '\t');
  scanf("%d", &b);
  if (ob == '+')
  {
    x = b + i;
  }
  else if (ob == '-')
  {
    x = i - b;
  }
  else if (ob == '*')
  {
    x = i * b;
  }
  else if (ob == '/')
  {
    x = i / b;
  }


char m;
l1 : printf("add ro vard kon");
scanf("%d",&i);
 do
 {
 scanf("%c",&ob);
 } while (ob==' '||ob=='\n'||ob=='\t');
 scanf("%d",&b);
 if (ob=='+')
 {
x=b+i;
 }
 else if (ob == '-')
 {
   x=i-b;
 }
 
printf("%d",x);

printf("\n miqay edame bedi? (y or n)");
fflush(stdin);
scanf("%C",&m);
if (m=='y')
{
  goto l1;
}











}
