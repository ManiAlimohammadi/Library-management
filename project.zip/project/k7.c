#include<stdio.h>
int main(){
FILE *mani;
int m,i,l;
printf("how meny preger do yuo have ? ");
scanf("%d",&m);
float arr1 [m];
mani=fopen("c.txt","r");
    for (i = 0; i < m; i++) {
        fscanf(mani, "%f\t", &arr1[i]);
    }
fclose(mani);
for(int j = 0 ; j<m;j++){
arr1[j]=((arr1[j]*1.8)+32);
}
mani=fopen("c.txt","a");
    for (l = 0; l < m; l++) {
        fprintf(mani, "\nfarenhit : %f\t", &arr1[l]);
    }
fclose(mani);
    return 0;
}