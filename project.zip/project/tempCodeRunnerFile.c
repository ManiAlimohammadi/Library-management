#include<stdio.h>
void arrange_three_numbers (float x,float y,float z){
int m ;
if (x>=y){
    if(x>=z){
        if(y>=z){
            printf("Sorted order of numbers:%f>%f>%f",x,y,z);
        }
        else{printf("Sorted order of numbers:%f>%f>%f",x,z,x);}
    }
    else{printf("Sorted order of numbers:%f>%f>%f",z,x,y);}
}
else{
    if(y>=z){
        if(x>=z){printf("Sorted order of numbers:%f>%f>%f",y,x,z);}
        else{printf("Sorted order of numbers:%f>%f>%f",y,z,x);}
    }
    else{printf("Sorted order of numbers:%f>%f>%f",z,y,x);}
}
}
int main() {
    FILE *mani;
    int m;

    printf("How many books do you have? ");
    scanf("%d", &m);

    char str_name[m];
    float arr_price[m];
    int arr_number[m];

    for (int i = 0; i < m; i++) {
        mani = fopen("b.txt", "r");
        fscanf(mani, "%s\t%f\t%d\n", str_name, &arr_price[i], &arr_number[i]);
        fclose(mani);
    }

    arrange_three_numbers(arr_price[0], arr_price[1], arr_price[2]);

    for (int j = 0; j < m; j++) {
        arr_price[j] = arr_price[j] - (arr_price[j] * 0.1); // Discounted price calculation
        mani = fopen("b.txt", "a"); // Open file in append mode
        fprintf(mani, "%f\n", arr_price[j]);
        fclose(mani);
    }

    return 0;
}