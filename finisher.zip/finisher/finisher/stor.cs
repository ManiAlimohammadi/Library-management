﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace finisher
{
    internal class stor : I_stor 
    {
        private book[] books = new book[0];
        private book[] SABADkharid = new book[0];

        public void loader(string adres)
        {
            if (File.Exists(adres))
            {
                string[] line = File.ReadAllLines(adres);
                books = new book[line.Length];
                for (int i = 0; i < line.Length; i++)
                {
                    string[] fild = line[i].Split('|');
                    string name = fild[0];
                    int id = int.Parse(fild[1]);
                    writer writer = new writer(fild[2]);
                    double price = double.Parse(fild[3]);
                    int mojodi = int.Parse(fild[4]);
                    books[i] = new book(name, id, writer, price, mojodi);

                }
            }

        }
        public void add(book Book)
        {
            Array.Resize(ref books, books.Length + 1);
            books[books.Length - 1] = Book;
        }
        public book serch(string name)
        {
            for (int i = 0; i < books.Length; i++)
            {
                if (books[i].name == name) { return books[i]; }
            }
            return null;
        }
        public void buy(string name)
        {
            book BOOK = serch(name);
            if (BOOK != null && BOOK.mojodi > 0)
            {
                Array.Resize(ref SABADkharid, SABADkharid.Length + 1);
                SABADkharid[SABADkharid.Length - 1] = BOOK;
                BOOK.mojodi--;
                Console.WriteLine("hale....");
            }
            else { Console.WriteLine("Ketab Ro Nadarim ... "); }
        }
        public void print()//سبد خریذ
        {
            double totalprice = 0;
            Console.WriteLine("your factot .... ");
            for (int i = 0; i < SABADkharid.Length; i++)
            {
                Console.WriteLine(SABADkharid[i]);
                totalprice +=SABADkharid[i].price;
            }
            Console.WriteLine($"you must pay : {totalprice}....");
        }
        public void sort()
        {
            for (int i = 0;i < books.Length-1; i++)
            {for (int j = 0; j < books.Length - 1 - i; j++)
                {
                    if (books[j].name.CompareTo(books[j+1].name) > 0)//tru
                    {book comak = books[j];
                        books[j] = books[j+1];
                        books[j+1] = comak;

                    }
                }

            }
        }
        public void save ()
        {
            using(StreamWriter sw = new StreamWriter("E:\\c#\\N.txt"))
            {
                for (int i = 0; i < books.Length; i++)
                {
                    sw.WriteLine($"{books[i].name}|{books[i].id}|{books[i].writer.name}|{books[i].price}|{books[i].mojodi}");
                }
            }



        }

    }
}
