﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finisher
{
    internal interface  I_stor
    {
        void loader(string adres);
        void add(book Book);
        book serch(string name);
        void buy (string name);
        void print();
        void sort();
        void save();
       
    }
}
