﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finisher
{//این کلاس نویسنده است که شی نویسنده یک ویژگی اسم دارد و با استفاده از متد پایه ای تو اسرینک نمایشش میدهیم
    internal class writer
    {
        public string name;
        public writer(string name)
        {
            this.name = name;
        }
        public override string ToString()
        {
            return name;
        }
    }

}
