﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finisher
{
    public class File_dataBass_
    {
        static private string adress = "E:\\c#\\N.txt";
        public string NewData=  File.ReadAllText("E:\\c#\\N.txt");
        public string DataBass()
        {
          return  NewData ;
        }
        public void printData(string b)
        {
            Console.WriteLine(b);
        }
    }
}
