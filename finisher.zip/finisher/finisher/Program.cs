﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace finisher
{
    internal class Program
    {
        static void Main(string[] args)
        {File_dataBass_ m =new File_dataBass_();
            string k = m.NewData;
            Console.WriteLine("your data bas is ...... \n"+k);
            //writer c =new writer("mohamad");
            //book b = new book ("book1",125,c,25.800,20);
            //Console.WriteLine(b);
            stor mystor = new stor();
            mystor.loader("E:\\c#\\N.txt");
            while(true)
            {
                Console.WriteLine("\n1.serch book by name ... \n2." +
                    "add book to data bass .... \n3.buy book... \n4.sho sabadkharid....\n5.sort databass....\n6.save book ....\n0.exit.... ");
                int inpot = int .Parse(Console.ReadLine());
               // stor n = new stor();
               // n.loader("E:\\c#\\N.txt");
                switch (inpot)
                {
                    case 0:
                        return;
                        break;
                        case 1:
                        Console.WriteLine("enter name of book you want ...");
                        string name = Console.ReadLine();
                
                        book Book =mystor.serch(name);
                        if(Book != null)
                        {
                            Console.WriteLine(Book);
                        }
                        else { Console.WriteLine("book nist mard .... "); }
                        break;
                        case 2:
                        Console.WriteLine("enter name of book you want add ...");
                        name = Console.ReadLine();
                        Console.WriteLine("enter id of book you want add ...");
                        int id = int .Parse(Console.ReadLine());
                        Console.WriteLine("enter writer of book you want add ...");
                        string writer = Console.ReadLine();
                        Console.WriteLine("enter price of book you want add ...");
                        double price = double .Parse(Console.ReadLine());
                        Console.WriteLine("enter mojodi of book you want add ...");
                        int mojodi = int .Parse(Console.ReadLine());
                        mystor.add(new book( name, id , new writer( writer),price,mojodi));
                        break;
                        case 3:
                        Console.WriteLine("enter name of book you want buy ...");
                        name= Console.ReadLine();
                        mystor.buy(name);
                        break;
                        case 4:
                        mystor.print();
                        break;
                        case 5:
                        mystor.sort(); break;
                        case 6:
                        mystor.save(); break;

                }
            }

            Console.ReadKey();
        }

    }
}
