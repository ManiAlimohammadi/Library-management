﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace finisher
{//این کلاس کتاب است که شی کتاب دارا ی ویژکی های نام شماره نام نویسنده قیمت و تعداد مجودی میباشد و با استفاده از توو استرنک نمایشش میدیم به نگارش مد نظر خودم
    internal class book
    {
        public string name;
        public int id;
        public writer writer;
        public double price;
        public int mojodi;
        public book(string name,int id , writer writer,double price, int mojodi) {
        this.name = name;
            this.id = id;
            this.writer = writer;
            this.price = price;
            this.mojodi = mojodi;
                }
        public override string ToString()
        {
            return $"{name},, number is : {id},,by : {writer},,price is : {price},,mojodi is : {mojodi}";
        }
    }
}
